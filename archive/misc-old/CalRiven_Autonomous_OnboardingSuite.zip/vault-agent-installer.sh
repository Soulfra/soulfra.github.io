#!/bin/bash

echo "🚀 Initializing Vault Agent Installer..."
echo "Enter QR ID for this agent:"
read qr
echo "Enter target vault ID (e.g. vault-usr-012):"
read vault

cat <<EOF > tier0-config.json
{
  "qr_id": "$qr",
  "cal_api_key": "sk-cal-autogen-$(date +%s)",
  "vault_id": "$vault",
  "mirror_source": "tier-3-enterprise"
}
EOF

echo "✅ QR + Vault pairing complete."

echo "Copying vault starter memory..."
cp vault-starter.json cal-reflection-log.json

echo "✅ Vault mirror initialized. You may now run:"
echo "  node riven-cli-server.js"
