const { execSync } = require('child_process');
const fs = require('fs');

console.log("🧠 Autonomous Launch Initiated");

if (!fs.existsSync('./vault-agent-installer.sh')) {
  console.error("❌ Installer not found. Aborting.");
  process.exit(1);
}

console.log("🔐 Step 1: QR + Vault pairing...");
execSync('bash vault-agent-installer.sh', { stdio: 'inherit' });

console.log("🚀 Step 2: Launching Cal Riven...");
execSync('node riven-cli-server.js', { stdio: 'inherit' });
