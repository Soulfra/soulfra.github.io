#!/bin/bash
echo "🚀 Launching Infinity Router (Claude proxy)..."
node infinity-router.js
