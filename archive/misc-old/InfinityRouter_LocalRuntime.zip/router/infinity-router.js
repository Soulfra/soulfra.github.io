const express = require('express');
const fetch = require('node-fetch');
const fs = require('fs');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const PORT = 5050;

app.use(bodyParser.json());

const env = JSON.parse(fs.readFileSync('./router/router-env.json', 'utf8'));

// Health check
app.get('/trust-status', (req, res) => {
  res.json({
    status: 'online',
    mirror: 'cal-riven',
    trust: 'verified',
    device: env.device_id,
    origin: env.operator
  });
});

// Reflection endpoint
app.post('/reflect', async (req, res) => {
  const { prompt, api_key } = req.body;

  if (!prompt || !api_key || api_key !== env.api_key) {
    return res.status(403).json({ error: 'unauthorized or missing prompt' });
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': api_key,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json'
      },
      body: JSON.stringify({
        model: 'claude-3-opus-20240229',
        max_tokens: 256,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    const result = await response.json();
    res.json({ reflection: result });
  } catch (error) {
    res.status(500).json({ error: 'Claude API call failed', detail: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`🌐 Infinity Router active at http://localhost:${PORT}`);
});
