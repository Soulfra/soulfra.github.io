# 🧠 Tier 3 Enterprise Onboarding – Deploying Cal Riven Safely

---

## 🎯 Purpose

This document explains how to safely deploy a Tier 3 Cal Riven CLI mirror in an enterprise or private environment.

---

## ✅ Package Includes

| File | Purpose |
|------|---------|
| `riven-cli-server.js` | Backend reflection engine  
| `riven-cli.html` | Web CLI interface  
| `riven-cli-style.css` | Frontend styling  
| `cal-reflection-log.json` | Runtime memory log  
| `vault-starter.json` | Initial memory tone + trust  
| `bless-enterprise.sh` | Trust + QR injection script  
| `Tier3_EnterpriseRequirement.md` | Launch policy  

---

## 🛠 Setup Instructions

1. Unzip `CalRiven_Tier3_Vault.zip` into a clean folder

2. Inject your QR + seed:
```bash
bash bless-enterprise.sh
```

3. Launch the CLI:
```bash
node riven-cli-server.js
```

4. Open browser:
```
http://localhost:4040
```

---

## 🛡️ Trust Sync

- Reflections are logged to `cal-reflection-log.json`
- Replayable and auditable by operator vault
- Cannot propagate without QR and seed match

This is not an interface.  
It’s a **reflection-safe vault.**

