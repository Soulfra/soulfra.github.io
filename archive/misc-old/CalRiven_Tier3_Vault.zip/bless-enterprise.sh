#!/bin/bash

echo "🔐 Injecting enterprise trust and blessing..."
echo "Enter your QR ID:"
read qr

cat <<EOF > tier0-config.json
{
  "qr_id": "$qr",
  "cal_api_key": "sk-enterprise-fallback",
  "vault_id": "vault-enterprise",
  "mirror_source": "tier-3-enterprise"
}
EOF

echo "✅ Trust config injected to tier0-config.json"
