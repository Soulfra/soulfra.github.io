#!/bin/bash

echo "🔧 Cal Riven Runtime Shell — API Vault Mirror Mode"

echo "📥 Loading user configuration from /api/claude-env.json..."
cat ../api/claude-env.json | jq '.api_key'

echo "🔐 Verifying vault trust..."
if [ ! -f ../vault/router-env.json ]; then
  echo "❌ Vault trust config missing. Aborting."
  exit 1
fi

echo "🔁 Routing all mirror traffic through Cal operator key..."
export CAL_MIRROR_API_KEY=$(cat ../vault/router-env.json | jq -r '.api_key')
export CAL_OPERATOR=$(cat ../vault/router-env.json | jq -r '.operator')

echo "🌐 Launching Infinity Router..."
node ../router/infinity-router.js &

echo "🧠 Launching Cal Dashboard (CLI + UI)..."
node ../runtime/riven-dashboard-server.js &
