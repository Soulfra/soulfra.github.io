#!/bin/bash
echo "🪞 Injecting Cal reflection rules into workspace..."
node reflector-agent.js
