#!/bin/bash

echo "🧠 Starting Cal Riven Tier 0 Onboarding..."

if [ ! -f user-vault.json ]; then
  echo "⏳ First time setup. Please provide your device ID:"
  read device
  echo "Enter your vault ID (e.g. vault-usr-001):"
  read vault
  echo "Enter your email (optional):"
  read email

  cat <<EOF > user-vault.json
{
  "device_id": "$device",
  "vault_id": "$vault",
  "email": "$email"
}
EOF
fi

echo "🛡 Agreeing to Tier 3 Enterprise Trust Terms..."
cat agent-tos.md

node supabase-device-link.js
node onboard-stripe.js

echo "✅ Booting Cal CLI..."
node riven-cli-server.js
