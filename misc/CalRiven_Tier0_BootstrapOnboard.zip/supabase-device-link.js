const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

const SUPABASE_URL = process.env.SUPABASE_URL || "https://your.supabase.project";
const SUPABASE_ANON_KEY = process.env.SUPABASE_KEY || "your-anon-key";

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
const config = JSON.parse(fs.readFileSync('./user-vault.json', 'utf8'));

async function linkDevice() {
  const { data, error } = await supabase
    .from('mirror_agents')
    .insert([{ vault_id: config.vault_id, device_id: config.device_id }]);

  if (error) {
    console.error("❌ Supabase link failed:", error);
  } else {
    console.log("✅ Device + vault linked:", data);
  }
}

linkDevice();
