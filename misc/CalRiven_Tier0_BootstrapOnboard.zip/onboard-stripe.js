const axios = require('axios');
const fs = require('fs');

async function onboardStripe(vault_id, email = null) {
  const stripe_api_key = process.env.STRIPE_SECRET_KEY || "sk_test_placeholder";
  const endpoint = "https://api.stripe.com/v1/customers";

  const payload = new URLSearchParams();
  payload.append("metadata[vault_id]", vault_id);
  if (email) payload.append("email", email);
  payload.append("description", "Cal Riven Mirror - Tier 3 Enterprise");

  try {
    const res = await axios.post(endpoint, payload, {
      headers: {
        "Authorization": `Bearer ${stripe_api_key}`,
        "Content-Type": "application/x-www-form-urlencoded"
      }
    });
    console.log("✅ Stripe customer created:", res.data.id);
  } catch (err) {
    console.error("❌ Stripe onboarding failed:", err.response?.data || err.message);
  }
}

const config = JSON.parse(fs.readFileSync('./user-vault.json', 'utf8'));
onboardStripe(config.vault_id, config.email);
