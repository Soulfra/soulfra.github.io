const fs = require('fs');

try {
  const vault = JSON.parse(fs.readFileSync('./user-vault.json', 'utf8'));
  if (!vault.vault_id || !vault.device_id) throw new Error("Invalid vault file.");

  console.log("✅ Vault pairing found:");
  console.log("🔐 Vault ID:", vault.vault_id);
  console.log("📎 Device ID:", vault.device_id);

  // Simulated: Add logic to verify Supabase + Stripe status if desired
  const statusOK = true; // Replace with real check or ping
  if (!statusOK) throw new Error("Service verification failed.");
} catch (err) {
  console.error("❌ Trust verification failed. Agent will not start.");
  process.exit(1);
}
