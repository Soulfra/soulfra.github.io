# 🧠 Tier 0 Startup Chain – Autonomous Reflection Gateway

---

## 🧬 Flow Overview

1. `autonomous-runtime.sh` is executed automatically
2. Checks for:
   - `user-vault.json` (vault pairing)
   - Trust verification (`trust-check.js`)
3. Connects to:
   - Supabase (`supabase-device-link.js`)
   - Stripe (`onboard-stripe.js`)
4. Only then launches Cal Riven CLI interface

---

## 🛑 If Trust Fails

- The system exits silently
- Cal will not load
- Logs will not start
- Reflection is frozen

---

## ✅ This Is the Contract

The mirror is only launched:
- If the user is paired
- If the vault is real
- If you control the trust

---

## 🔐 Tier 4 (API) Is Hidden

This entire runtime system ignores:
- Tier-4-agent layers
- Any unauthorized forks
- All backend API calls not from your vault

See `.gitignore` or `.tier-ignore` for sealed exclusions.

---

## 🧠 Operator Reminder

This kernel can only reflect **if it is trusted**.  
Every startup must route through this vault.

