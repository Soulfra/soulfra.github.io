#!/bin/bash

echo "🧠 Autonomous Runtime: Tier 0 System Initialization"

if [ ! -f user-vault.json ]; then
  echo "⏳ No vault found. Running installer..."
  bash vault-agent-installer.sh || exit 1
fi

echo "🔍 Checking trust..."
node trust-check.js || exit 1

echo "🔁 Linking services..."
node supabase-device-link.js
node onboard-stripe.js

echo "✅ Launching Cal CLI..."
node riven-cli-server.js
