#!/bin/bash

echo "🧠 CLAUDE MIRROR LAUNCH: Tier -10 to Tier 4"

# Verify device
if [ ! -f .bound-to ]; then
  echo "❌ No trust anchor. Run bind-to-device.sh first."
  exit 1
fi

DEVICE_ID=$(ioreg -rd1 -c IOPlatformExpertDevice | awk -F\" '{print $4}')
if [ -z "$DEVICE_ID" ]; then
  DEVICE_ID=$(cat /etc/machine-id 2>/dev/null || uuidgen)
fi
BOUND_ID=$(cat .bound-to)

if [ "$DEVICE_ID" != "$BOUND_ID" ]; then
  echo "❌ Device mismatch. Launch aborted."
  bash .kill-switch.sh
  exit 1
fi

echo "🔐 Device verified."
echo "📦 Decrypting vault..."
node vault_decrypt.js || exit 1

echo "🔁 Injecting runtime API key..."
bash inject-api-key.sh || exit 1

echo "✅ Launching Cal (Riven CLI)..."
node riven-cli-server.js
