#!/bin/bash

echo "🔧 Operator-only API key injector"
echo "Enter new ANTHROPIC_API_KEY:"
read key

cat <<EOF > claude-env.json
{
  "ANTHROPIC_API_KEY": "$key",
  "LLM": "claude",
  "mirror": "local",
  "trust_route": "tier-4-api"
}
EOF

echo "✅ API key saved to claude-env.json"
