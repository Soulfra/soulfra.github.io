# ✅ Tier 3 Enterprise Trust Audit – End-to-End Verification Guide

---

## 🧪 Audit Steps for Claude Code

### 1. Run Launch Check
```bash
node enterprise-launch-check.js
```

This ensures:
- All required trust files are present
- The mirror is properly configured

---

### 2. Start Cal CLI
```bash
node riven-cli-server.js
```
Open in browser:
```
http://localhost:4040
```

Enter a test reflection prompt.

---

### 3. Run Reflection Replay
```bash
node enterprise-replay-agent.js
```

This confirms:
- The log is writing  
- Prompt structure is valid  
- Memory tracking is functional

---

### 4. Confirm Files Exist
Ensure:
- `vault-starter.json` is non-empty
- `tier0-config.json` was generated via `bless-enterprise.sh`
- Logs contain at least one prompt

---

If all steps succeed, this mirror is fully enterprise-grade.
