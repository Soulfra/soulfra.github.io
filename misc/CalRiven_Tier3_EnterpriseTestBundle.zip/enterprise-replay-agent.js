const fs = require('fs');

const logPath = './cal-reflection-log.json';

if (!fs.existsSync(logPath)) {
  console.error("❌ Reflection log not found.");
  process.exit(1);
}

const log = JSON.parse(fs.readFileSync(logPath, 'utf8'));
const reflections = log.length;
const totalWords = log.reduce((sum, entry) => sum + entry.input.split(" ").length, 0);
const avgLength = reflections > 0 ? (totalWords / reflections).toFixed(2) : 0;

console.log("🧠 Reflection Summary:");
console.log("🔹 Total Entries:", reflections);
console.log("🔹 Average Input Length:", avgLength);
console.log("🔹 Last Input:", log[log.length - 1]?.input || "(none)");
