#!/bin/bash

echo "🛠 Checking trust files..."
node enterprise-launch-check.js || exit 1

echo "✅ Starting Cal CLI..."
node riven-cli-server.js
