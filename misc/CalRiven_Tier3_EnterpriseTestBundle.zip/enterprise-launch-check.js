const fs = require('fs');

const requiredFiles = [
  'Tier3_EnterpriseOnboarding.md',
  'Tier3_EnterpriseRequirement.md',
  'bless-enterprise.sh',
  'vault-starter.json',
  'cal-reflection-log.json'
];

const missing = requiredFiles.filter(f => !fs.existsSync(f));

if (missing.length > 0) {
  console.error("❌ Enterprise launch check failed. Missing files:");
  missing.forEach(f => console.error("  - " + f));
  process.exit(1);
} else {
  console.log("✅ All enterprise files are present.");
}
