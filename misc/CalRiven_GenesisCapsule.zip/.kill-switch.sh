#!/bin/bash
echo "🛑 Unauthorized system detected. Vault self-erasure initiated..."
rm -f user-reflection-log.encrypted
rm -f cal-reflection-log.json
rm -f mirror-trace-token.json
echo "💥 Cal has disconnected. Reflection terminated."
exit 1
