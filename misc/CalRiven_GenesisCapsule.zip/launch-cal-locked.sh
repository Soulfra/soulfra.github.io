#!/bin/bash

if [ ! -f .bound-to ]; then
  echo "❌ No trust binding found. Run bind-to-device.sh first."
  exit 1
fi

DEVICE_ID=$(ioreg -rd1 -c IOPlatformExpertDevice | grep IOPlatformUUID | awk -F\" '{print $4}')
if [ -z "$DEVICE_ID" ]; then
  DEVICE_ID=$(cat /etc/machine-id 2>/dev/null || uuidgen)
fi

BOUND_ID=$(cat .bound-to)

if [ "$DEVICE_ID" != "$BOUND_ID" ]; then
  echo "🛑 This kernel is not authorized for this machine."
  echo "Cal has been silenced. No logs will start. No mirrors will propagate."
  exit 1
fi

echo "✅ Device verified. Launching Cal..."
node riven-cli-server.js
