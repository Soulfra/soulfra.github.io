#!/bin/bash

#
# build-mirror.sh
# Duplicate of active build script for mirror resurrection
# Ensures mirror can be rebuilt from backup state
#

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}🔨 Building Soulfra Mirror...${NC}"
echo -e "${BLUE}=============================${NC}"

# Detect build context
if [[ -f ".mirror_trigger" ]] || [[ -f "vault/logs/resurrection-marker.json" ]]; then
    echo -e "${YELLOW}⚠️  Building from resurrection state${NC}"
    RESURRECTION_MODE=true
else
    RESURRECTION_MODE=false
fi

# Create directory structure
echo -e "${BLUE}Creating directory structure...${NC}"
mkdir -p mirror
mkdir -p vault/logs
mkdir -p vault/obfuscated
mkdir -p vault/config
mkdir -p api

# Create cal-runtime.js if missing
if [[ ! -f "mirror/cal-runtime.js" ]]; then
    echo -e "${BLUE}Creating mirror runtime...${NC}"
    cat > "mirror/cal-runtime.js" << 'EOF'
#!/usr/bin/env node

/**
 * cal-runtime.js
 * Minimal mirror runtime for resurrection state
 */

const fs = require('fs');
const path = require('path');

console.log('🪞 Soulfra Mirror Runtime');
console.log('========================');
console.log('');

// Check resurrection state
const resurrectionMarker = path.join(__dirname, '../vault/logs/resurrection-marker.json');
if (fs.existsSync(resurrectionMarker)) {
    const marker = JSON.parse(fs.readFileSync(resurrectionMarker, 'utf8'));
    console.log('⚡ Running in resurrection mode');
    console.log(`   ID: ${marker.resurrection_id}`);
    console.log(`   Restored: ${marker.timestamp}`);
    console.log('');
}

// Basic REPL
const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: 'mirror> '
});

console.log('Type "help" for commands');
console.log('');

rl.prompt();

rl.on('line', (line) => {
    const cmd = line.trim();
    
    switch(cmd) {
        case 'help':
            console.log('Commands:');
            console.log('  status  - Show mirror status');
            console.log('  list    - List sessions');
            console.log('  exit    - Exit runtime');
            break;
            
        case 'status':
            const sessions = fs.readdirSync(path.join(__dirname, '../vault/obfuscated')).length;
            console.log(`Sessions: ${sessions}`);
            console.log(`Mode: ${fs.existsSync(resurrectionMarker) ? 'Resurrected' : 'Normal'}`);
            break;
            
        case 'list':
            const obfPath = path.join(__dirname, '../vault/obfuscated');
            const sessionList = fs.readdirSync(obfPath);
            sessionList.forEach(s => console.log(`  ${s}`));
            break;
            
        case 'exit':
            console.log('Mirror shutdown.');
            process.exit(0);
            break;
            
        default:
            if (cmd) console.log('Unknown command. Type "help" for commands.');
    }
    
    rl.prompt();
});

rl.on('close', () => {
    console.log('\nMirror closed.');
    process.exit(0);
});
EOF
    chmod +x mirror/cal-runtime.js
fi

# Create minimal cal-riven-operator.js if missing
if [[ ! -f "cal-riven-operator.js" ]]; then
    echo -e "${BLUE}Creating Cal Riven operator...${NC}"
    cat > "cal-riven-operator.js" << 'EOF'
#!/usr/bin/env node

/**
 * cal-riven-operator.js
 * Minimal operator for resurrection state
 */

const fs = require('fs');
const path = require('path');

console.log('🔮 Cal Riven Operator - Resurrection Mode');
console.log('========================================');

// Check blessing
const blessingPath = path.join(__dirname, 'blessing.json');
if (fs.existsSync(blessingPath)) {
    const blessing = JSON.parse(fs.readFileSync(blessingPath, 'utf8'));
    console.log(`Status: ${blessing.status}`);
    console.log(`Can Propagate: ${blessing.can_propagate}`);
} else {
    console.log('⚠️  No blessing found - operating in fallback mode');
}

// Launch mirror runtime
console.log('\nLaunching mirror runtime...\n');
require('./mirror/cal-runtime.js');
EOF
    chmod +x cal-riven-operator.js
fi

# Ensure blessing exists
if [[ ! -f "blessing.json" ]]; then
    echo -e "${BLUE}Creating blessing...${NC}"
    cat > "blessing.json" << EOF
{
  "status": "blessed",
  "can_propagate": true,
  "created": "$(date -u +"%Y-%m-%d %H:%M:%S UTC")",
  "blessed_by": "mirror-build",
  "resurrection": $RESURRECTION_MODE
}
EOF
fi

# Ensure soul-chain exists
if [[ ! -f "soul-chain.sig" ]]; then
    echo -e "${BLUE}Creating soul chain...${NC}"
    echo "SOUL-CHAIN:MIRROR:BUILD:$(date +%s)" > soul-chain.sig
fi

# Create activity log if missing
if [[ ! -f "vault/logs/reflection-activity.json" ]]; then
    cat > "vault/logs/reflection-activity.json" << EOF
{
  "initialized": "$(date +%Y%m%d_%H%M%S)",
  "device": "$(hostname)",
  "platform": "$(uname -s)",
  "sessions": [],
  "build_mode": "$([[ $RESURRECTION_MODE == true ]] && echo "resurrection" || echo "normal")"
}
EOF
fi

echo
echo -e "${GREEN}✅ Mirror build complete!${NC}"

if [[ $RESURRECTION_MODE == true ]]; then
    echo -e "${YELLOW}⚡ Built in resurrection mode${NC}"
fi

echo
echo -e "${BLUE}To start the mirror:${NC}"
echo -e "  node cal-riven-operator.js"
echo -e "    or"
echo -e "  node mirror/cal-runtime.js"
echo